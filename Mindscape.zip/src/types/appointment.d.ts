declare module 'Appointment-main/src/components/Appointment/AppointmentPage.jsx' {
    const AppointmentPage: React.ComponentType;
    export default AppointmentPage;
} 