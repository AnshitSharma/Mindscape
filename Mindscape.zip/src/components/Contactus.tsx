import React from 'react'
import Contact from './Contact'

function Contactus() {
  return (
    <div ><Contact/></div>
  )
}

export default Contactus