#!/bin/bash
node start