#!/bin/bash
node dist/server.js